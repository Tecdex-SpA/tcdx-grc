# Diseño funcional sin ejecución

Entidad conceptual FuenteNormativa -> EdicionNormativa -> UnidadNormativa -> ObligacionRequisito -> ControlRecomendado -> Prueba/Evidencia -> Evaluacion -> Hallazgo -> Accion -> Auditoria/Certificacion. El marco y versión constituyen identidades separadas; un control puede satisfacer múltiples obligaciones sin declarar equivalencia legal automática. Documentos normativos con política de acceso y licencias independiente. Un texto derogado mantiene trazabilidad histórica y no se borra.

Reglas: tenant_id obligatorio para todas las evaluaciones y evidencias privadas; catálogo central controlado por Platform; no asignar identidad de tenant ficticia; RBAC deny-by-default; excepciones y cambios auditables; no asumir permisos ni esquema antes de inspección; retención según clasificación. No atribuir certificación a plataforma. Gestionar versiones, fecha de emisión, de entrada en vigencia, retirada, país, entidad emisora, hash, idioma, fuente, estado de revisión y tipo (obligación, referencia informativa, control propuesto).

En importación futura: contrato CSV firmado, esquema normalizado luego de validar estructura real, preflight, dry-run, conteos de registros por norma, idempotencia por identificador/version/hash, rollback, QA, comparación por tenant, verificaciones auditables y aprobación explícita.
