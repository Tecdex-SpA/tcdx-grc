# Brechas abiertas, no ocultarlas

ALTA: faltan ISO 9001:2026 original y validación uno a uno de sus requisitos; ISO 9001:2026 es publicación nueva. ALTA: los catálogos de ISO 42001 del presente kit son por dominios y prácticas, no reproducción exhaustiva del Anexo A. ALTA: requiere cotejo exacto de artículos y vigencias en Ley 21.719 y Ley 21.663; incorporar reglamentos y actos administrativos relevantes. MEDIA: corroborar indexación y fecha/edición de enmiendas ISO 27001:2022/Amd 1:2024 y otras enmiendas en fuentes originales. MEDIA: matriz de transición ISO 9001 2015-2026 debe cotejarse con versión publicada. MEDIA: definir fuentes de datos de riesgo y evidencia de integración Vulnera+GRC, que aún no debe declararse implementada.

No realizar cargas automáticas hasta resolver las brechas de alta prioridad y obtener aprobación rectora.
