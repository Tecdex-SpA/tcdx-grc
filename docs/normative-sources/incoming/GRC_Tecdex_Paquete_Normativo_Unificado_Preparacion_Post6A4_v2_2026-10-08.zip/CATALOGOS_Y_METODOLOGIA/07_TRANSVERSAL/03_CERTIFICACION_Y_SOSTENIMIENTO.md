# Evaluación y certificación

ISO 9001, ISO/IEC 27001 e ISO/IEC 42001 admiten evaluación por entidades de certificación acreditadas según alcance. Plan referencial: precertificación interna -> auditoría etapa 1 documentación -> etapa 2 funcionamiento -> tratamiento de hallazgos -> decisión externa -> seguimientos periódicos -> renovación. Frecuencia, alcance y esquemas contractuales definidos por certificador.

Las leyes 21.663 y 21.719 no deben catalogarse como 'certificación ISO': mantener verificación de obligaciones, fiscalización, dictámenes y evidencias; no se infiere sello estatal por usar GRC. Estado de cumplimiento requiere fecha y evaluación. Una evidencia multiuso no garantiza conformidad con dos normas sin pruebas independientes.

Revisión recurrente: reglas legales por fecha; nuevas resoluciones y reglamentos; revisiones de riesgos ante cambios; ensayos de incidentes; control de proveedores; auditoría y revisión de dirección; retención de evidencias y de hallazgos.
