# Repositorio integral de preparación normativa - GRC Tecdex

Fecha de corte: 08-10-2026. **Paquete de preparación, NO de importación automática.**

## Cobertura
- ISO 9001:2015: referencia histórica completa y catálogo de implementación (norma retirada por ISO tras edición 2026).
- ISO 9001:2026: kit integral preparatorio previo reutilizado y conservado, sin afirmar cobertura literal definitiva.
- ISO/IEC 27001:2022: sistema de gestión y 93 controles de referencia Anexo A (37 organizacionales, 8 personas, 14 físicos, 34 tecnológicos).
- ISO/IEC 42001:2023: sistema de gestión de IA, dominios de anexos A-D, prácticas de control, riesgos e impactos.
- Ley chilena 21.663: obligaciones de ciberseguridad, clasificación de sujetos, gestión de incidentes y fiscalización, con aplicabilidad condicionada.
- Ley chilena 21.719: protección de datos, régimen legal de tratamientos; vigencia general 01-12-2026; gestionar vigencia temporal, reglamentos y reformas.

## Interpretación correcta
**Normas ISO:** los catálogos son resumenes profesionales y controles implementables propuestos; no sustituyen ni reproducen el texto normativo, ni representan cobertura jurídica/normativa garantizada. Verificar contra original, especialmente edición 2026. **Leyes:** usar PDF de BCN, marcar automáticamente los artículos candidatos y realizar validación jurídica de cada relación. La Ley 21.719 se presenta como ley modificatoria de la 19.628: para operar cumplimiento se necesita texto consolidado y su fecha aplicable. La NCh 27001:2023 es una adopción chilena idéntica de ISO/IEC 27001:2022; no representa una norma internacional publicada en 2023.

## Alcance técnico y gobierno
Uso reservado como insumo para implementación futura. No ejecutar cargas ni modificar Git/BD/QA/prod. GRC Tecdex: dominio canónico https://grc.tecdex.net/ ; grc.tecdx.net inválido. Tenant isolation, RBAC deny-by-default, registro de fuentes y versiones, hashes, auditoría, controles de acceso a PDF licenciados, trazabilidad de evidencias y estado legal por fecha. Todo frontend debe estar en español; traducir títulos externos al presentar, preservar texto original en fuente.

## Revisión y puertas de avance
1. Cotejar títulos, cláusulas, numeración y obligatoriedad con originales. 2. Validar vigencia y reglamentos por asesor jurídico. 3. Aprobar vocabulario y catálogo canónico. 4. Determinar mapeo con tablas reales, sin presuponer nombres de tablas. 5. Diseñar importador idempotente reversible en transacción, hashes, dry-run. 6. Validación multi-tenant y RBAC, E2E, QA, autorización humana antes de cualquier despliegue. 7. No presentar certificado o cumplimiento legal definitivo sin evidencia de auditoría y evaluación competente.

## Datos del paquete
Los CSV están en UTF-8 con BOM para Excel en español. La columna `nivel_confirmacion` advierte cuándo un elemento requiere cotejo. Los PDFs se conservan sin modificación en sus carpetas. SHA256SUMS garantiza detección de alteraciones.
