# Evaluacion de conformidad

Estados separados: NO_EVALUADO, NO_APLICA_JUSTIFICADO, SIN_EVIDENCIA, PARCIAL, CONFORME, NO_CONFORME. Las excepciones requieren autoridad y justificacion contextual; no convertir en NO_APLICA automaticamente por falta de evidencias.

Cada control puede tener varias evidencias y cada evidencia cubrir varios controles. Conservar: origen, periodo, autor, version, clasificacion, revision, hash, decisiones y retencion. Exigir objetividad y suficiencia de evidencia.

Indicadores agregados son SOLO de seguimiento interno y no equivalen a certificacion. Evitar un porcentaje arbitrario como declaracion de conformidad normativa. Clasificar hallazgos segun criterio de auditoria, gravedad sustentada y reglas del organismo certificador.
