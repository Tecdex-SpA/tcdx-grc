# Mantenimiento continuo

Mensual: KPI, reclamos, no conformidades y prioridades; trimestral: riesgos, oportunidades, proveedores y eficacia; semestral: formacion, conocimiento y auditorias segun programa; anual: contexto, alcance, politica, objetivos, revision por direccion y programa de auditoria. Son frecuencias orientativas y deberan adaptarse al riesgo y a cada organizacion.

Control de cambios: cuando cambia el proceso, producto, ley o condicion externa, evaluar alcance, riesgos, evidencias, competencia, documentacion y eficacia; registrar responsable, aprobacion y cierre.

Las evidencias deben representar operaciones reales; las plantillas vacias son instrumentos para recopilar informacion, no prueba de cumplimiento.
