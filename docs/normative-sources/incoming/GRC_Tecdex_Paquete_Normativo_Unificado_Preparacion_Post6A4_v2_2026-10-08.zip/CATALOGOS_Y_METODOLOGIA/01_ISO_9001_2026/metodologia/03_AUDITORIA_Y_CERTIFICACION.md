# Auditoria y certificacion

Programa basado en riesgo y cobertura por procesos/requisitos; auditor independiente del proceso auditado, competencia validada; agenda, entrevistas, muestreo, registros, hallazgos, contradiccion y cierre. La ISO 19011:2026 entrega directrices sobre auditorias de sistemas de gestion.

El certificador externo define la auditoria de etapa 1 (preparacion/documentacion), etapa 2 (implantacion/eficacia), seguimiento y recertificacion. Es necesario comprobar acreditacion, alcance, sedes y actividades cubiertas. Una herramienta SaaS no puede autoemitir certificados ISO acreditados.

**Transicion:** ISO TC176 informa 31-03-2028 como inicio de nuevas certificaciones acreditadas exclusivamente 2026 y 30-09-2029 para completar transicion de certificados 2015 existentes. Revisar actualizaciones oficiales.

Checklist operativo en catalogos/checklist_certificacion.csv.
