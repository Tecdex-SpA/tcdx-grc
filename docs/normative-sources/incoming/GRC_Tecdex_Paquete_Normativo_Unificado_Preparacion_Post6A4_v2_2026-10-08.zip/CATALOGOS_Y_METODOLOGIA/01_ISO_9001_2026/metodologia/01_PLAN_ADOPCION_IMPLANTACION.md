# Metodologia integral de implantacion

1. Patrocinio ejecutivo, diagnostico organizacional, alcance y no aplicabilidades justificadas.
2. Mapa de procesos y propietarios; ficha de proceso con recursos, secuencia, riesgos, indicadores y resultados.
3. Matriz de partes interesadas, clientes, requisitos contractuales y regulatorios relevantes; determinacion documentada de relevancia climatica.
4. Politica, objetivos medibles, liderazgo, cultura de calidad, comportamiento etico, autoridad y rendicion de cuentas.
5. Separar registro de riesgos de cartera de oportunidades; definir evaluacion, decisiones de tratamiento, responsables y eficacia.
6. Gestion documental con aprobacion, control de cambio, versionado, acceso, retencion y evidencias integras.
7. Implantar controles operativos de diseño, compras, proveedores, servicio/produccion, trazabilidad, liberacion y no conformidades segun aplicabilidad.
8. Recolectar evidencia operativa real durante ciclos suficientes para demostrar eficacia; las frecuencias incluidas son orientativas, no exigencias textuales.
9. Auditoria interna imparcial, revision por direccion, CAPA con causas y pruebas de eficacia.
10. Auditoria externa (etapa 1 y 2), decision independiente, vigilancia posterior y recertificacion.

La ejecucion de controles no garantiza certificacion ni crea automaticamente conformidad.
