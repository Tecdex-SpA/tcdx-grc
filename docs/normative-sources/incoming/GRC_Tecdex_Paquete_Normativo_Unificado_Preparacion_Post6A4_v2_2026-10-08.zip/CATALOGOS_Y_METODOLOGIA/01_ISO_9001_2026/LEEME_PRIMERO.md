# GRC Tecdex - Kit de conocimiento ISO 9001:2026

**Fecha de corte:** 08-10-2026. **Estado:** PREPARADO PARA REVISION, NO AUTORIZADO PARA CARGA AUTOMATICA.

ISO 9001:2026 fue publicada el 16-09-2026. Este paquete NO contiene el texto completo de la norma. Incluye un **modelo operativo amplio de controles propuestos** diseñado para construir, operar, mantener y preparar una certificacion del SGC. No se presenta como transcripcion ni como inventario normativo exhaustivo y exacto de requisitos de la edicion 2026: esa conformidad solo puede cerrarse con un cotejo clausula-por-clausula contra el texto normativo 2026.

**Orden de uso:** (1) verificar requisitos frente al ejemplar 2026; (2) aprobar catalogo canonico y mapeos; (3) cargar entorno de ensayo via mecanismos formales del proyecto; (4) verificar multi-tenant, RBAC, integridad y trazabilidad; (5) hacer pruebas operativas; (6) activar para clientes mediante autorizacion formal.

**Archivos:** catalogos/MATRIZ_MAESTRA_ISO9001_2026.xlsx; catalogos/*.csv; plantillas/*.csv; metodologia/*.md; integracion/*.md; fuentes/*.csv; integracion/manifest.json.

**Regla:** los controles catalogados son modelo GRC operable y no deben confundirse con requisitos literales ISO. No afirmar que organizacion alguna esta certificada por usar esta herramienta; solo un certificador competente decide y emite certificados.
