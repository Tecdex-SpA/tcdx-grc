# Entidades logicas (sin afirmar tablas fisicas)

NormativeFramework -> FrameworkEdition -> RequirementReference (validada) -> ControlDefinition (propuesto/validado) -> ControlApplicability (tenant y contexto) -> Process -> Risk/Opportunity -> Objective/KPI -> Evidence -> Assessment -> Finding -> CAPA -> Audit -> ManagementReview -> CertificationRecord.

Relaciones muchos-a-muchos: requisito-control, control-proceso, control-evidencia, evidencia-hallazgo, riesgo-control, KPI-proceso. Cada puente requiere provenance, version y estado de validacion. Diferenciar requisitos auditables, recomendaciones operativas, ejemplos e informacion del Anexo A.

Estados de ciclo editorial: BORRADOR -> EN_COTEJO -> VALIDADO_TECNICAMENTE -> APROBADO_PARA_CATALOGO -> PUBLICADO -> RETIRADO. Versiones historicas inmutables; nuevas versiones generan revision y trazabilidad. Nunca generar status de cumplimiento en base a presencia de un PDF.
