# Contrato preparatorio de integracion - NO EJECUTAR

Producto: GRC Tecdex. URL publica canonica: https://grc.tecdex.net/ . **grc.tecdx.net es incorrecto** y debe bloquearse como error de configuracion sin DNS fallback.

NO realizar cambios al repositorio, esquema, migraciones, BD, contratos activos, datos QA/prod, despliegues, commits ni PR mediante este paquete. Su proposito es documentar conocimiento futuro.

Usar exclusivamente modelo canonico vigente del proyecto, catalogo unico de Role/Permission, RBAC deny-by-default, aislamiento estricto multi-tenant y trazabilidad de auditoria; no suponer tablas. Version de norma/edicion separada de catalogo de controles propuestos; conservar origen y version, no reutilizar identificadores de ISO 9001:2015 como si la numeracion 2026 estuviera cotejada.

Secuencia de aprobacion: inventario + cotejo con texto oficial 2026 -> aprobar correspondencia y semantica -> generar propuesta de mapeo compatible con esquema existente -> gates automatizados y revision humana -> importacion transaccional reproducible, reversible e idempotente -> reconciliacion cantidades/hashes -> validacion end-to-end.

Mantener referencias a evidencias por tenant, clasificacion, politicas de retencion, trazas y autor; evitar incluir documentos normativos en endpoints publicos. Ningun estado 'certificado' puede atribuirse sin respaldo de certificador externo.
