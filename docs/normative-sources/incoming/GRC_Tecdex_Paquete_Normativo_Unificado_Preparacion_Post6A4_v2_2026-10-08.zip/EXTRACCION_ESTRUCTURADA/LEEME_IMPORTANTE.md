# GRC Tecdex — extracción normativa intermedia

## Alcance

Extracción textual completa por página de los cinco PDF aportados por el usuario, con bloques y coordenadas de página, detección automatizada de tablas y candidatos a encabezados normativos. Se incluyen los PDF originales sin alteraciones.

## Estado real

**PREEXTRACCIÓN ESTRUCTURADA COMPLETADA; VALIDACIÓN SEMÁNTICA PENDIENTE.** Los archivos `heading_candidates.jsonl` son candidatos heurísticos y NO constituyen una jerarquía normativa validada. Las tablas detectadas automáticamente pueden estar incompletas; revisar visualmente contra PDF, especialmente anexos y tablas. El texto extraído puede diferir de la presentación visual (columnas, caracteres, saltos de línea). Los textos completos se encuentran en `pages.jsonl` y `full_text_page_marked.txt`, con referencia a página PDF.

## Siguiente paso después de 6A.4

1. Validar semánticamente todas las jerarquías y encabezados contra originales.
2. Conciliar anexos, tablas, controles, referencias y numeración; registrar discrepancias.
3. Verificar integridad por documento, páginas y contenido antes de declarar `FULLY_VALIDATED`.
4. Determinar autorizaciones de uso y publicación aplicables al entorno.
5. Mapear exclusivamente a entidades/contratos canónicos del repositorio; no generar SQL paralelo.
6. Ejecutar importación QA solo tras autorización separada.

## Formatos

- `pages.jsonl`: una fila JSON por página, texto íntegro extraído, bloques con coordenadas y tablas detectadas.
- `heading_candidates.jsonl`: posibles encabezados, requieren revisión.
- `tables_detected.jsonl`: tablas detectadas, no garantiza completitud.
- `full_text_page_marked.txt`: texto continuo con separadores de página.
- `document_manifest.csv`: hash SHA256 de originales y métricas.
- `extraction_result.json`: estado global.

No se ha modificado código, PostgreSQL, QA ni contratos.
