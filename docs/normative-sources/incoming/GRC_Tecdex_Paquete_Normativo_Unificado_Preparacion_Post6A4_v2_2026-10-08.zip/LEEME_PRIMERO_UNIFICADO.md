# GRC Tecdex — paquete normativo unificado de preparación (v2)

Fecha de consolidación: 2026-10-08. Estado: **PREPARACIÓN DOCUMENTAL; NO APTO PARA IMPORTACIÓN DIRECTA**.

## Origen y contenido

Se consolidaron sin reescribir los bytes de origen de:
- `GRC_Tecdex_Extraccion_Normativa_Estructurada_v1.zip` (preextracción de cinco PDF, páginas, candidatos a encabezados, tablas detectadas y banderas de calidad).
- `GRC_Tecdex_Paquete_Integral_Todas_Normas_y_Leyes_2026-10-08.zip` (catálogos, metodología, matrices, plantillas, fuentes y propuestas de integración).

Carpetas:
- `ORIGINALES/`: cinco PDF de fuentes normativas seleccionadas, conservados byte a byte.
- `EXTRACCION_ESTRUCTURADA/`: resultados de preextracción existentes, **sin validación semántica integral**.
- `CATALOGOS_Y_METODOLOGIA/`: material nuevo íntegro no PDF (incluidos catálogos propuestos, matrices, fuentes, plan ISO 9001:2026 y metodología).
- `CONTROL_DE_INTEGRIDAD/`: manifiesto de hashes, trazabilidad, exclusiones y control de calidad.

## Cobertura y límites

PDF completos incluidos: ISO 9001:2015 (edición NOM), NCh-ISO/IEC 27001:2023 (adopción de ISO/IEC 27001:2022), ISO/IEC 42001:2023, Ley 21.663 y Ley 21.719 (textos PDF aportados). No se incluye el texto oficial íntegro de ISO 9001:2026, ISO 9001:2015/Amd1:2024 ni ISO/IEC 27001:2022/Amd1:2024. ISO 9001:2026 contiene **material preparatorio propuesto**, NO cláusulas verificadas contra texto oficial de 2026.

El catálogo maestro nuevo tiene 211 filas únicas por ID: ISO9001=27, ISO27001=116, ISO42001=45, LEY21663=10, LEY21719=13. No confundir filas propuestas con obligaciones normativas verificadas, ni asumir cobertura exhaustiva de los textos oficiales. Los índices de artículos de leyes son **autodetectados para revisión**. La Ley 21.719 es modificatoria: se requiere texto consolidado de la Ley 19.628 y validación jurídica por fecha. No asumir vigencia, aplicabilidad, equivalencia intermarcos ni certificación automática.

Los PDF secundarios no seleccionados del paquete nuevo se enumeran en `CONTROL_DE_INTEGRIDAD/PDF_EXCLUIDOS.csv` con SHA-256. No se destruyó ni reemplazó el ZIP original proporcionado por el usuario.

## Integración futura después de STEP 6A.4 y antes de STEP 6A.5

1. Cotejo editorial/semántico de extracción, jerarquías, tablas, artículos, numeración, controles y obligatoriedad con originales y versiones vigentes.
2. Validación jurídica y de licencias/autorización de reproducción y acceso a textos completos, por documento/edición.
3. Separación estricta de texto normativo, metadatos de fuente, obligación validada, control propuesto, metodología, evidencia y plantillas.
4. Mapeo **exclusivo** contra el modelo canónico real de GRC y contratos/permissions publicados; no inferir nombres de tablas, endpoints ni campos desde los modelos lógicos propuestos.
5. Publicación/autoridad de vocabularios y versionado, trazabilidad y procedencia; sin duplicados, hardcodes ni esquemas paralelos.
6. Diseño y prueba de importación idempotente, dry-run, transaccional, auditable y reversible; **ninguna ejecución de BD/QA/producción sin autorización expresa**.
7. Aislamiento tenant, RBAC deny-by-default, licencias de acceso al PDF, evidencias, SoD, retención, E2E y reconciliación de cantidades/hashes.
8. UI 100 % en español; traducciones centralizadas de etiquetas; mantener intactos códigos y textos fuente originales.

Dominio público canónico: https://grc.tecdex.net/ . `grc.tecdx.net` es incorrecto y no admite fallback.

**Este ZIP no altera repositorio, BD, QA ni estados de STEP 6A.3/6A.4.**
