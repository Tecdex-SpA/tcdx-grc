# Fuentes externas para cotejo (no incorporadas como originales)

- Ley 19.628, versión vigente al 20-10-2026: https://www.bcn.cl/leychile/Navegar?idNorma=141599&idVersion=2023-05-09
- Ley 19.628, versión consolidada con vigencia diferida 01-12-2026: https://www.bcn.cl/leychile/navegar?idNorma=141599&idVersion=2026-12-01
- Ley 21.719 (modificatoria): https://www.leychile.cl/leychile/Navegar?idNorma=1209272

Estas URLs son referencias para recuperación y cotejo posterior. No se descargaron ni incorporaron como fuentes íntegramente verificadas a este paquete.
