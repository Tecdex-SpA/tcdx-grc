# Revisión funcional del paquete normativo — 20-10-2026

ESTADO: ESPECIFICACIÓN PARA REVISIÓN, NO IMPLEMENTACIÓN NI HOMOLOGACIÓN TÉCNICA COMPLETADA.

## Decisiones del Product Owner
- N-01 a N-17 aceptadas conceptualmente. Experiencia: Comprender / Implementar / Demostrar, contextualizable por tenant.
- Los 211 registros del catálogo original se aceptan como **candidatos operativos para revisión**, sin borrar ninguno. Esta decisión de producto NO convierte propuestas en obligaciones legales verificadas, ni sustituye cotejo normativo.
- Mantener ISO 9001:2015 y 2026 como ediciones independientes; coexistencia por tenant.
- IA futura: contenido versionado, procedencia, contexto, resultados explicables, revisión humana; no construir un motor IA en este paso.
- Prohibido crear esquema, columnas, endpoints, permisos o catálogos paralelos sin verificar baseline v1.12 y contratos canónicos.

## Estado de trabajo que NO debe falsificarse
- Extracciones de PDF: candidatas; revisión semántica con IA y cotejo determinista por unidad pendiente.
- Catálogos: 211 candidatos aceptados para procesamiento; homologación física y semántica a entidades existentes pendiente.
- Fuentes externas: verificar texto oficial y fecha; no publicar borradores como norma definitiva.
- Ley 21.719: distinguir Ley modificatoria 21.719 de Ley 19.628 consolidada, incluyendo versión vigente y diferida 01-12-2026.
- Aplicabilidad regulatoria: recomendación automatizada, nunca decisión jurídica autónoma; autoridad del tenant según contrato RBAC/SoD real.

## Flujo de homologación previsto
1. Inventariar archivos, hashes y procedencia; no alterar originales.
2. IA sugiere jerarquía de unidades y obligaciones; conservar citas precisas, nivel de confianza y versión.
3. Cotejar cada unidad con fuente auténtica; marcar validada, discrepante o no corroborada.
4. Mapear FrameworkVersion, NormativeUnit, Requirement y controles existentes sin duplicar identidades.
5. Comparar 211 registros con entidades canónicas: coincidencia, posible duplicado, propuesta no normativa, conflicto.
6. Dry-run de importación y matriz de cambios sin escritura; solicitar autorización antes de toda importación.
7. Auditoría, idempotencia, aislamiento de tenant, versionado, rollback y pruebas exigidas por rector.

## Ajustes tenant y aprobación
El administrador tenant podrá proponer ajustes de actividad, evidencia, periodicidad y nivel de confirmación únicamente mediante mecanismos de configuración/override ya autorizados en el contrato. Conservar inalterada la fuente normativa Platform, registrar justificación, autor, fecha, versión, impacto y aprobación de la autoridad competente. La aprobación por gerente propuesta por el Product Owner está sujeta a resolver rol, permisos y SoD de la baseline; no inferir que iniciar sesión y pulsar OK es autorización suficiente.

## Contexto empresarial
Texto libre de contexto suministrado por autoridad tenant; propuesta de clasificación de aplicabilidad con fundamento, vigencia, supuestos, confianza y preguntas pendientes. El administrador acepta/rechaza con justificación. La IA no decide por sí sola aplicabilidad legal ni altera registros canónicos sin operación autorizada. Considerar minimización de datos, clasificación, retención y aislamiento.

## Tres niveles de unidad normativa
- COMPRENDER: texto o referencia oficial con licencia, explicación editorial, propósito, alcance, excepciones, versión, vigencia, fuente, citas.
- IMPLEMENTAR: actividades orientativas, responsabilidades, ejemplos por sector y tamaño, controles relacionados, frecuencia sugerida diferenciada de exigida.
- DEMOSTRAR: evidencias requeridas cuando la fuente las impone versus recomendadas, criterios de suficiencia, evaluaciones existentes, hallazgos y trazabilidad.

## Matrices gráficas
Una matriz gráfica debe construirse como vista de relaciones canónicas, no como datos paralelos. Filas/columnas seleccionables: marco-versión, unidad, requisito, control, evidencia, evaluación, riesgo, acción, responsable y estado cuando el modelo permita. Filtros por tenant, edición, proceso, fecha, aplicabilidad y vigencia; celdas con vínculo, cobertura y explicación de ausencia de dato. Exportaciones y cálculos solo conforme contratos vigentes. Evitar porcentajes engañosos cuando hay insuficiencia de datos.

## Gates de aceptación propuestos para evaluación rectora
Fuente verificable; jerarquía íntegra; mapeo sin duplicados; contenido editorial distinguible; matrices navegables y trazables; tenant aislado; roles/SoD; cambios auditables; temporalidad; versión; accesibilidad; prueba de reemplazo de contenido ISO 9001:2026 sin alterar la identidad 2015; preparación IA sin deuda. No asignar estos gates como oficiales hasta cotejarlos con baseline v1.12.
