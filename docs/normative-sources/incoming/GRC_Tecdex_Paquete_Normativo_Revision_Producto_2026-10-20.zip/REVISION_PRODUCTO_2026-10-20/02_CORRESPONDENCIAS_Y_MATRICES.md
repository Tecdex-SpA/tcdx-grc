# Correspondencias propuestas existentes en el ZIP

Todas las siguientes relaciones están marcadas `POTENCIAL` en el origen. No son equivalencias jurídicas ni cumplimiento automático.

| Origen | Destino | Proceso | Referencia origen | Referencia destino | Justificación |
|---|---|---|---|---|---|
| ISO9001 | ISO27001 | Control de documentos | 7.5 | 7.5 | Control de versiones y registros |
| ISO9001 | ISO42001 | Gestión de riesgos | 6.1 | 6.1 | Analizar riesgos y oportunidades específicos |
| ISO27001 | LEY21663 | Incidentes y continuidad | A.5.24-A.5.30 | Regulación de incidentes | Evidencias compartidas con revisión de aplicabilidad |
| ISO27001 | LEY21719 | Seguridad y privacidad | A.5.34 | Seguridad de datos | Misma evidencia técnica, conclusiones jurídicas distintas |
| ISO42001 | LEY21719 | Datos y perfilamiento | A.7 | Protección de datos | Gobernanza de conjuntos de datos personales en IA |
| ISO9001 | ISO42001 | Auditoría interna | 9.2 | 9.2 | Proceso transversal de auditoría |

## Reglas de visualización
- Vista normativa por marco/edición, y vista multimarca con cruces de requisitos-controles-evidencias.
- Cada celda indica `propuesta`, `validada con fuente`, `confirmada por tenant` o `sin evidencia`; no inferir cumplimiento por relación potencial.
- La empresa configura ejes y filtros de la matriz sin crear un modelo de datos paralelo.
